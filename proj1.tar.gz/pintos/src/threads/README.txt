========================
PROJECT 1 - ALARM MEGA
========================
To get the alarm-mega to work, I had to add one file and modify several others in order to get it to 
work.

Files added:
alarm-mega.ck - This was a copy of alarm-multiple.ck

Files modified:
Rubric.alarm
tests.c
tests.h
alarm-wait.c

I then rebuilt pintos and it can now run alarm-mega
